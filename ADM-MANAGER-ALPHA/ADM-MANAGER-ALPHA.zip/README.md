﻿# ADM-MANAGER-ULTIMATE (VERSAO: ALPHA)
# UPDATE 03/01/2021

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/ADM-MANAGER-ALPHA/Imagenes/ADM_MANAGER_ULTIMATE.jpg)

-------------------------------------------------------------------------------

**Manager Script**


## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian) 
* Recomendamos Ubuntu 14.04 Server x86_64 / Ubuntu 16.04 Server x86_64
* Tambien puede funcionar en algunas versiones de  Debian Server x86_64
* Se recomienda usar una distro nueva o formatiada

## Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/ADM-MANAGER-ALPHA/instala.sh; chmod 777 instala.sh* && ./instala.sh*

## Download Proyecto

https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/ADM-MANAGER-ALPHA/ADM-MANAGER-ALPHA.zip

-------------------------------------------------------------------------------

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆

```

**By: [  ⃘⃤꙰✰ ]**